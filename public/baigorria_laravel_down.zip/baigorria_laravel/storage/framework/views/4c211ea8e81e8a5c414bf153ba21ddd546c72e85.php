<!DOCTYPE html>

<html lang="es">

<head>
    <?php echo $__env->make('page.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <style media="screen">
        .noPadNS {
            padding-top: 0 !important;
            padding-bottom: 0 !important;
        }

        .colorCat {
            color: #454545;
        }

        .colorPro {
            color: #A3A3A3;
        }
    </style>

    <div class="container" style="width: 82%;">
        <div class="row">
            <div class="col l3 s12">
                <ul class="collapsible z-depth-0" style="border: 0;">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="<?php if($productoIs->id_categoria == $categoria->id): ?> active <?php endif; ?>">
                        <div class="collapsible-header colorCat">
                            <div class="active" style="<?php if($productoIs->id_categoria == $categoria->id): ?> color: #003E66!important; font-weight: 600; <?php endif; ?>"><?php echo $categoria->{'titulo_'.$idioma}; ?></div>
                        </div>
                        <div class="collapsible-body noPadNS active">
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($producto->id_categoria == $categoria->id): ?>
                                <ul class="collapsible z-depth-0 noPadNS" style="border: 0;">
                                    <a class="colorPro" style="<?php if($productoIs->id == $producto->id): ?> color: #003E66!important; font-weight: 600;  <?php endif; ?>" href="<?php echo e(route('producto',$producto->id)); ?>"><?php echo $producto->{'titulo_'.$idioma}; ?></a>
                                </ul>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col l9 s12">
                <div class="col l6 s12">
                    <div class="carousel carousel-slider center" data-indicators="true">
                        <?php if($producto->imagen): ?>
                        <div class="carousel-item white-text">
                            <img src="<?php echo e(asset('img/productos/'.$producto->imagen)); ?>" style="width:100%;">
                        </div>
                        <?php endif; ?>
                        <?php $__currentLoopData = $presentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presentaciones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($presentaciones->imagen1): ?>
                            <div class="carousel-item white-text"><img src="<?php echo e(asset('img/presentaciones/'.$presentaciones->imagen1)); ?>" style="width:100%;"></div>
                            <?php endif; ?>
                            <?php if($presentaciones->imagen2): ?>
                                <div class="carousel-item white-text"><img src="<?php echo e(asset('img/presentaciones/'.$presentaciones->imagen2)); ?>" style="width:100%;"></div>
                                <?php endif; ?>
                                <?php if($presentaciones->imagen3): ?>
                                    <div class="carousel-item white-text"><img src="<?php echo e(asset('img/presentaciones/'.$presentaciones->imagen3)); ?>" style="width:100%;"></div>
                                    <?php endif; ?>
                                    <?php if($presentaciones->imagen4): ?>
                                        <div class="carousel-item white-text"><img src="<?php echo e(asset('img/presentaciones/'.$presentaciones->imagen4)); ?>" style="width:100%;"></div>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col s12 l6">
                    <div class="fcGris2 fs28 fw6"><?php echo $productoIs->{'titulo_'.$idioma}; ?></div>
                    <div class="lineaHorizontal"></div>
                    <div class="fcGris2 fs17 fw4"><?php echo $productoIs->{'texto_'.$idioma}; ?></div>
                    <?php if($productoIs->plano): ?>
                    <div><img src="<?php echo asset('img/planos/'.$productoIs->plano); ?>"></div>
                    <?php endif; ?>
                    <div style="margin-top: 20px;"><a class="boton" href="#"><?php echo app('translator')->getFromJson('general.consultar'); ?></a></div>

                </div>
                <div class="col s12 mt15">
                    <div class="fcAzul2 fs20 fw5"><?php echo app('translator')->getFromJson('general.detalles'); ?></div>
                    <div class="lineaHorizontal"></div>
                    <div class="">
                        <table class="responsive-table highlight centered">
                            <thead>
                                <tr class="fcAzul2 fw5">
                                    <td><?php echo app('translator')->getFromJson('general.tabla_code'); ?></td>
                                    <td><?php echo app('translator')->getFromJson('general.tabla_text'); ?></td>
                                    <td><?php echo app('translator')->getFromJson('general.tabla_aaaa'); ?></td>
                                    <td><?php echo app('translator')->getFromJson('general.tabla_bbbb'); ?></td>
                                    <td><?php echo app('translator')->getFromJson('general.tabla_cccc'); ?></td>
                                    <td><?php echo app('translator')->getFromJson('general.tabla_dddd'); ?></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $presentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($detalles->codigo); ?></td>
                                    <td><?php echo $detalles->{'titulo_'.$idioma}; ?></td>
                                    <td><?php echo e($detalles->medida_a); ?></td>
                                    <td><?php echo e($detalles->medida_b); ?></td>
                                    <td><?php echo e($detalles->medida_c); ?></td>
                                    <td><?php echo e($detalles->terminacion); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col s12 mt15 mb15">
                    <div class="fcAzul2 fs20 fw5"><?php echo app('translator')->getFromJson('general.relacionados'); ?></div>
                    <div class="lineaHorizontal"></div>
                    <div class="">
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $cont ++;
                        ?>
                        <?php if($cont < 4): ?> <div class="col s12 m4 mt15">
                            <div class="card z-depth-0">
                                <div class="card-image center-align">
                                    <a href="<?php echo e(route('producto', $producto->id)); ?>">
                                        <div class="efecto">
                                            <span class="central"><i class="material-icons">add</i></span>
                                        </div>
                                        <img src="<?php echo e(asset('img/productos/'.$producto->imagen)); ?>" style="border: 1px solid #DDD;">
                                    </a>
                                </div>
                                <div class="card-content cero center-align " style="border: 1px solid #DDD; height: 100px; display:flex; justify-content: center; align-items:center;">
                                    <div class=" fw5 fs16 gris13"><?php echo ($producto->{'titulo_'.$idioma}); ?></div>
                                </div>
                            </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    </div>

    <?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).ready(function() {
        $('.datepicker').datepicker({
            format: 'dd-mm-yyyy',
            selectYears: 200,
            min: new Date(2018, 11, 23),
            max: new Date(2080, 12, 31)
        });
    });

    $(document).ready(function() {
        $('.carousel').carousel();
    });
    $(document).ready(function() {
        $('select').formSelect();
    });

    setTimeout(autoplay, 2400);

    function autoplay() {
        $('.carousel').carousel('next');
        setTimeout(autoplay, 2400);
    }
</script>
