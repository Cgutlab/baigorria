<!DOCTYPE html>

<html lang="es">

<head>
    <?php echo $__env->make('page.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('privada.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div style="background: #00446F;">
        <section style="background-image: url('<?php echo e(asset('img/banner/'.$banner->imagen)); ?>'); background-repeat: no-repeat; background-size: cover; ">
            <div class="container" style="width:100%;">
                <div class="row">
                    <div class="col s12" style="padding: 70px;">
                        <div class="fc1 fs20"><?php echo $banner->{'titulo_'.$idioma}; ?></div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div class="row" style=" margin-bottom: 80px;">
        <div class="container center-align" style="width:100%;">
          <?php $__empty_1 = true; $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="row" style="margin-top: 40px;">
                <div><img src="<?php echo e(asset('img/listadeprecios/'.$listas->imagen)); ?>" alt=""></div>
                <div style="display: flex; justify-content: center; align-items: center;">
                  <div>
                    <span><?php echo $listas->{'titulo_'.$idioma}; ?></span>
                    <span><a href="<?php echo e(asset('img/listadeprecios/'.$listas->ficha)); ?>" target="_blank"><i class="material-icons">arrow</i></a></span>
                  </div>
                </div>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <h2>Sin registros</h2>
          <?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('privada.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $("[name='record']").on("change", function(e) {
        let edit_id = $(this).val();
        window.location.href = edit_id;
    });

    $(document).ready(function() {
        $('select').formSelect();
    });
</script>
