<!DOCTYPE html>

<html lang="es">

<head>

    <?php echo $__env->make('page.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

    <?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.4877427694582!2d-58.55350528459142!3d-34.61711276571442!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcb7f9cd0fe7f3%3A0x23752a29f204ac9d!2sTaller+Baigorria!5e0!3m2!1ses!2sar!4v1545311796445"
      width="100%" height="324" frameborder="0" style="border:0" allowfullscreen></iframe>

    <section class="Contacto" style="margin-bottom: 80px;">

        <div class="container">

            <div class="row" style="margin-top: 50px;">

                <div class="col l4 fs17">

                    <div class="row" style="margin-bottom: 15px;">

                        <div class="col s1"><i class="material-icons fs20" style="color: #00456D;">location_on</i></div>

                        <div class="col s11"><a target="_blank" href="https://www.google.com/maps/search/<?php echo e($direccion->texto); ?>" class="fc8 fs17 hover"><?php echo e($direccion->texto); ?></a></div>

                    </div>

                    <div class="row" style="margin-bottom: 15px;">

                        <div class="col s1"><i class="material-icons fs20" style="color: #00456D;">phone_in_talk</i></div>

                        <div class="col s11"><a href="tel:<?php echo e($telefono->texto); ?>" class="fc8 fs17 hover"><?php echo e($telefono->texto); ?></a></div>

                    </div>


                    <div class="row" style="margin-bottom: 15px;">

                        <div class="col s1"><i class="material-icons fs20" style="color: #00456D;">email</i></div>

                        <div class="col s11"><a href="mailto:<?php echo e($correo->texto); ?>" class="fc8 fs17 hover"><?php echo e($correo->texto); ?></a></div>

                    </div>


                </div>

                <div class="col l8">

                    <?php echo Form::open(['route'=>'contacto.enviar', 'method'=>'POST']); ?>


                    <div class="row">

                        <div class="input-field col s6">

                            <label for="nombre">
                                <?php echo app('translator')->getFromJson('general.form_fname'); ?></label>
                                <?php echo Form::text('nombre',null,['class'=>'validate', 'required']); ?>


                        </div>
                        <div class="input-field col s6">

                            <label for="apellido">
                                <?php echo app('translator')->getFromJson('general.form_lname'); ?></label>
                                <?php echo Form::text('apellido',null,['class'=>'validate', 'required']); ?>


                        </div>
                        <div class="input-field col s6">

                            <label for="email">
                                <?php echo app('translator')->getFromJson('general.form_correo'); ?></label>
                                <?php echo Form::email('email',null,['class'=>'validate', 'required']); ?>


                        </div>
                        <div class="input-field col s6">

                            <label for="nombre">
                                <?php echo app('translator')->getFromJson('general.form_telefono'); ?></label>
                                <?php echo Form::text('telefono',null,['class'=>'validate', 'required']); ?>


                        </div>
                        <div class="col s12">

                            <div class="input-field">

                                <label for="mensaje">
                                    <?php echo app('translator')->getFromJson('general.form_text'); ?></label>
                                    <?php if(isset($presentacion)): ?>

                                    <?php echo Form::textarea('mensaje', $presentacion->codigo. ' ' .$presentacion->{'titulo_'.$idioma}, ['class'=>'materialize-textarea']); ?>

                                    <?php else: ?>
                                    <?php echo Form::textarea('mensaje', null, ['class'=>'materialize-textarea']); ?>

                                    <?php endif; ?>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col l6 m12">

                                <div class="g-recaptcha" data-sitekey="6LdG__kSAAAAAA7yCcKdci4ZCNlek_QJfsZyTc7h"></div>

                            </div>

                            <div class="col l6 m12">

                                <label>

                                    <input type="checkbox" name="acepto" required />

                                    <span>

                                        <a href="#modal1" class="modal-trigger" style="color:#494949;">

                                            <div class="fs15 gris15"><?php echo $terminos->{'titulo_'.$idioma}; ?></div>

                                        </a>

                                    </span>

                                </label>

                            </div>

                        </div>

                        <div class="col s12" style="margin-top: 25px;">

                            <div class="col s12 no-padding">

                                <button type="submit" class="btn waves-light z-depth-0 left" id="botonEstadoAnterior" style="background-color: #003E66; padding: 0px 50px 35px 50px; color: white; font-weight: bold; border: 3px solid #003E66;">ENVIAR</button>

                            </div>

                        </div>

                    </div>

                    <?php echo Form::close(); ?>


                </div>

            </div>

        </div>

    </section>



    <div id="modal1" class="modal">

        <div class="modal-content">

            <h4>Términos y condiciones</h4>

            <p><?php echo $contenido->texto; ?></p>

        </div>

        <div class="modal-footer">

            <a href="#!" class="modal-close waves-effect waves-green btn-flat">Agree</a>

        </div>

    </div>



    <?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</body>

</html>



<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script src='https://www.google.com/recaptcha/api.js?hl=es'></script>



<script type="text/javascript">
    $(document).ready(function() {

        $('.modal').modal();

    });

    $(document).ready(function() {

        $('.datepicker').datepicker({

            format: 'dd-mm-yyyy',

            selectYears: 200,

            min: new Date(2018, 11, 23),

            max: new Date(2080, 12, 31)

        });

    });

    $(document).ready(function() {

        $('select').formSelect();

    });
</script>