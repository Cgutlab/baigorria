<!DOCTYPE html>

<html lang="es">

<head>
    <?php echo $__env->make('privada.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('privada.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('privada.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php if(count($errors) > 0): ?>
    <div class="col s12 card-panel red lighten-4 red-text text-darken-4">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo $error; ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
    <div class="col s12 card-panel green lighten-4 green-text text-darken-4  center-align">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>


    <div style="background: #00446F; margin-bottom: 45px;">
        <section style="padding: 50px; background-image: url('<?php echo e(asset('img/banner/'.$banner->imagen)); ?>'); background-repeat: no-repeat; background-size: cover; ">
            <div class=" container" style="width:100%;">
                <div class="align-center">
                    <div class="fc1 fs20">
                        <div class="container">
                            <nav class="z-depth-0" style="">

                                <div class="nav-wrapper z-depth-0">

                                    <?php echo Form::open(['route'=>'catalogo', 'method' => 'POST']); ?>


                                    <div class="input-field" style="background: white; border: 1px solid gray;">
                                        <input id="busqueda" name="busqueda" type="search" placeholder="<?php echo $banner->{'titulo_'.$idioma}; ?>" required>

                                        <label class="label-icon" for="search"><i class="material-icons" style="color: #AFAFAF; font-weight: 600;">search</i></label>

                                        <i class="material-icons azul" style="color: #3E4EB8;">chevron_right</i>

                                    </div>

                                    <?php echo Form::close(); ?>


                                </div>

                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <?php
    $sumatotales = 0;
    ?>
    <div class="row" style=" margin-bottom: 45px;">
        <div class="container" style="width:100%;">
            <table class="highlight bordered responsive-table centered">
                <thead>
                    <tr class="fc15 fw5">
                        <td></td>
                        <td>Código</td>
                        <td>Categoría</td>
                        <td style="text-align: center;">Precio Unitario $</td>
                        <td>Cantidad</td>
                        <td style="text-align: center;">Cantidad por caja</td>
                        <td>Unidades</td>
                        <td style="text-align: center;">Subtotal $</td>
                        <td></td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo Form::open(['route'=>'carrito.actual','METHOD'=>'POST']); ?>

                    <?php
                    $id_presentacion = $row->id;
                    $cantidad = $row->qty;
                    $precio = $row->price;
                    $id_presentacion = $row->id;
                    $cantidad = $row->qty;
                    $precio = $precio;
                    if($row->options->cantidadxcaja != ''){
                    $unidades = $row->options->cantidadxcaja * $row->qty;
                    }else{
                    $unidades = $cantidad;
                    }
                    $subtotal = $precio * $unidades;
                    ?>
                    <tr>
                        <td style="width:60px;">
                            <div>
                                <input type="hidden" value="<?php echo e($row->id); ?>" name="id">
                                <input type="hidden" value="<?php echo e($row->rowId); ?>" name="id_carrito">
                            </div>
                            <?php if($row->options->imagen1): ?>
                                <div><img src="<?php echo e(asset('img/presentaciones/'.$row->options->imagen1)); ?>" style="width:60px"></div>
                                <?php elseif($row->options->imagen2): ?>
                                    <div><img src="<?php echo e(asset('img/presentaciones/'.$row->options->imagen2)); ?>" style="width:60px"></div>
                                    <?php elseif($row->options->imagen3): ?>
                                        <div><img src="<?php echo e(asset('img/presentaciones/'.$row->options->imagen3)); ?>" style="width:60px"></div>
                                        <?php elseif($row->options->imagen4): ?>
                                            <div><img src="<?php echo e(asset('img/presentaciones/'.$row->options->imagen4)); ?>" style="width:60px"></div>
                                            <?php else: ?>
                                            <div><img src="<?php echo e(asset('img/productos/'.$row->options->imagen)); ?>" style="width:60px"></div>
                                            <?php endif; ?>
                        </td>
                        <td><b><?php echo $row->name; ?></b></td>
                        <td style="text-align: left;"><?php echo $row->options->{'titulo_'.$idioma}; ?></td>
                        <td><?php echo $row->price; ?></td>
                        <td>
                            <div><input type="number" value="<?php echo e($row->qty); ?>" name="cantidad" style="width: 52px; height: 35px; border: 1px solid #ECECEC; border-radius: 4px; padding-left: 5px; background: #F8F8F8; box-shadow: none;" required></div>
                        </td>
                        <td>
                            <?php if($row->options->cantidadxcaja): ?>
                                <?php echo $row->options->cantidadxcaja; ?>

                                <?php else: ?>
                                <?php echo '-'; ?>

                                <?php endif; ?>
                        </td>
                        <td>
                            <?php if($row->options->cantidadxcaja): ?>
                                <?php echo e(($row->options->cantidadxcaja * $row->qty)); ?>

                                <?php else: ?>
                                <?php echo e($row->qty); ?>

                                <?php endif; ?>
                        </td>
                        <td><?php echo e($subtotal); ?></td>
                        <td>
                            <a href="<?php echo e(url('carrito/delete/'.$row->rowId)); ?>" style="color:#A2A2A2; border:2px solid #A2A2A2; border-radius: 100%; background: inherit; width: 30px; height: 30px; display:flex; justify-content: center; align-items: center;">
                                <i class="material-icons">close</i>
                                <span class="rpedido">
                                </span>
                            </a>

                        </td>
                    </tr>
                    <?php echo Form::close(); ?>

                    <?php
                    $sumatotales = $subtotal + $sumatotales;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="center-align">
                        <h3>¡No hay productos agregados al carrito!</h3>
                    </div>
                    <?php endif; ?>
                </tbody>
            </table>
            <br>
            <?php if(Cart::count() > 0): ?>
            <?php echo Form::open(['route'=>'carrito.enviar', 'method'=>'POST']); ?>

            <div class="row">
                <div class="container" style="width: 87%;">
                    <div class="col l8 m12">
                        <div class="input-field col s12">
                            <textarea id="mensaje" name="mensaje" class="materialize-textarea"></textarea>
                            <label for="mensaje">Mensaje adicional ...</label>
                        </div>
                    </div>
                    <div class="col l4 m12">
                        <input type="hidden" name="subtotal" value="<?php echo e($sumatotales); ?>">
                        <input type="hidden" name="iva" value="<?php echo e($sumatotales * 0.21); ?>">
                        <input type="hidden" name="total" value="<?php echo e($sumatotales * 0.21 + $sumatotales); ?>">
                        <table>
                            <tbody>
                                <tr>
                                    <td>Subtotal</td>
                                    <td style="text-align: right;">
                                        $<?php echo e($sumatotales); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>IVA</td>
                                    <td style="text-align: right;">
                                        $<?php echo e($sumatotales * 0.21); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>TOTAL (IVA Incluido)</td>
                                    <td style="text-align: right;">
                                        $<?php echo e($sumatotales * 0.21 + $sumatotales); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="">
                                            <a href="<?php echo e(route('catalogos')); ?>" class="boton" style="background: white; color: #003E66; border: 1px solid #003E66;">CONTINUAR</a>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="">
                                            <button type="submit" class="boton">REALIZAR&nbsp;PEDIDO</button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

            <?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('privada.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('privada.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $("[name='record']").on("change", function(e) {
        let edit_id = $(this).val();
        window.location.href = edit_id;
    });

    $("#cantidad").change(function() {
        let cantidad = $(this).val();
        let precio = $("#input_precio").val();

        $('#precio').html("$" + (cantidad * precio).toFixed(2));
    });

    $(document).ready(function() {
        $('select').formSelect();
    });
</script>