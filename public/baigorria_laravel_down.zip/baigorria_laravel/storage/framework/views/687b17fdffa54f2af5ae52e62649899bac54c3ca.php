<!DOCTYPE html>

<html lang="es">

<head>
    <?php echo $__env->make('page.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container" style="width: 82%; padding: 70px 0 70px 0;">
        <div class="row">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col s12 m6 l4">
                <div class="card z-depth-0">
                    <div class="card-image center-align">
                        <a href="<?php echo e(route('productos', $categoria->id)); ?>">
                            <div class="efecto">
                                <span class="central"><i class="material-icons">add</i></span>
                            </div>
                            <img src="<?php echo e(asset('img/categorias/'.$categoria->imagen)); ?>" style="border: 1px solid #DDD; width: 100%; height: 100%;">
                        </a>
                    </div>
                    <div class="card-content cero center-align " style="border: 1px solid #DDD; height: 80px;">
                        <div class=" fw5 fs16 gris13 editorRico "><?php echo $categoria->{'titulo_'.$idioma}; ?></div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).ready(function() {
        $('.datepicker').datepicker({
            format: 'dd-mm-yyyy',
            selectYears: 200,
            min: new Date(2018, 11, 23),
            max: new Date(2080, 12, 31)
        });
    });

    $(document).ready(function() {
        $('select').formSelect();
    });
</script>
