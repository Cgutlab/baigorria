<!DOCTYPE html>

<html lang="es">

<head>
    <?php echo $__env->make('page.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <main class="registro mt50 mb15">
        <div class="container">
            <div class="row">
                <div class="col l4 s12">
                    <?php echo Form::open(['route'=>'logindistribuidor', 'method'=>'POST', 'class' => 'col s12']); ?>

                    <h4 class="datos" style="color: #2962E8;">
                        <?php echo app('translator')->getFromJson('general.form_registrado'); ?></h4>
                        <div class="row">
                            <div class="usuario_input input-field col s12">
                                <?php echo Form::text('user',null,['class'=>'']); ?>

                                <label for="user">
                                    <?php echo app('translator')->getFromJson('general.form_correo'); ?></label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="contrasena_input input-field col s12">
                                <?php echo Form::password('password',['class' => 'awesome']); ?>

                                <label for="password">
                                    <?php echo app('translator')->getFromJson('general.form_pass'); ?></label>
                            </div>
                        </div>
                        <button class="btn waves-effect waves-light right" style="background: #2962E8!important;" name="action" type="submit">
                            <?php echo app('translator')->getFromJson('general.form_join'); ?>
                            <i class="material-icons right">
                                send
                            </i>
                        </button>
                        <?php echo Form::close(); ?>

                </div>
                <div class="col l8">
                    <?php echo Form::open(['route'=>'registro.store', 'method'=>'POST', 'files' => true]); ?>

                    <h3 class="registrate" style="color: #2962E8;">
                        <?php echo app('translator')->getFromJson('general.form_registrate'); ?></h3>
                        <p class="desc" style="color: #2962E8;">
                            <?php echo app('translator')->getFromJson('general.form_instruccion'); ?></p>
                            <h4 class="datos" style="color: #2962E8;">
                                <?php echo app('translator')->getFromJson('general.form_datos'); ?></h4>

                                <div class="row">
                                    <div class="input-field col s12">
                                        <label for="">
                                            <?php echo app('translator')->getFromJson('general.form_fname'); ?></label>
                                            <?php echo Form::text('first_name',null,['class'=>'']); ?>

                                    </div>
                                    <div class="input-field col s12">
                                        <label for="">
                                            <?php echo app('translator')->getFromJson('general.form_lname'); ?></label>
                                            <?php echo Form::text('last_name',null,['class'=>'']); ?>

                                    </div>
                                    <div class="input-field col s12">
                                        <label for="">
                                            <?php echo app('translator')->getFromJson('general.form_razon'); ?></label>
                                            <?php echo Form::text('razon_social',null,['class'=>'']); ?>

                                    </div>
                                    <div class="input-field col s12">
                                        <label for="">
                                            <?php echo app('translator')->getFromJson('general.form_correo'); ?></label>
                                            <?php echo Form::email('user',null,['class'=>'']); ?>

                                    </div>
                                    <div class="input-field col s12">
                                        <label for="">
                                            <?php echo app('translator')->getFromJson('general.form_pass'); ?></label>
                                            <?php echo Form::password('password',null,['class' => 'awesome']); ?>

                                    </div>
                                    <div class="input-field col s12">
                                        <label for="">
                                            <?php echo app('translator')->getFromJson('general.form_telefono'); ?></label>
                                            <?php echo Form::text('phone',null,['class'=>'']); ?>

                                    </div>
                                    <div class="input-field col s12">
                                        <label for="">
                                            <?php echo app('translator')->getFromJson('general.form_direccion'); ?></label>
                                            <?php echo Form::text('address',null,['class'=>'']); ?>

                                    </div>
                                    <div class="input-field col s12">
                                        <label for="">
                                            <?php echo app('translator')->getFromJson('general.form_localidad'); ?></label>
                                            <?php echo Form::text('localidad',null,['class'=>'']); ?>

                                    </div>
                                </div>
                                <button class="btn waves-effect waves-light right" style="background: #2962E8!important;" name="action" type="submit">
                                    <?php echo app('translator')->getFromJson('general.form_save'); ?>
                                    <i class="material-icons right">
                                        send
                                    </i>
                                </button>
                                <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </main>

    <?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).ready(function() {
        $('.datepicker').datepicker({
            format: 'dd-mm-yyyy',
            selectYears: 200,
            min: new Date(2018, 11, 23),
            max: new Date(2080, 12, 31)
        });
    });

    $(document).ready(function() {
        $('select').formSelect();
    });
</script>