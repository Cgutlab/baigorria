<!DOCTYPE html>

<html lang="es">

<head>
    <?php echo $__env->make('page.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <style media="screen">
        .noPadNS {
            padding-top: 0 !important;
            padding-bottom: 0 !important;
        }

        .colorCat {
            color: #454545;
        }

        .colorPro {
            color: #A3A3A3;
        }
    </style>

    <div class="container" style="width: 82%;">
        <div class="row">
            <div class="row"  style="margin-bottom: 50px; margin-top: 30px;">
            <div class="col l12" style="color: color: #595959!important; font-family: 'Monserrat';">
                <a href="<?php echo e(route('categorias')); ?>" style="color: #595959!important;" class="fw5">Categorias</a>&nbsp;|&nbsp;
                <a href="<?php echo e(route('productos', $item->id)); ?>" style="color: #595959!important;" class="fw5"><?php echo $item->{'titulo_'.$idioma}; ?></a>
            </div>
            </div>
            <div class="col l3">
                <ul class="collapsible z-depth-0" style="border: 0;">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="collapsible-header colorCat">
                            <div><?php echo $categoria->{'titulo_'.$idioma}; ?></div>
                        </div>
                        <div class="collapsible-body noPadNS">
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($producto->id_categoria == $categoria->id): ?>
                                <ul class="collapsible z-depth-0 noPadNS" style="border: 0;">
                                    <a class="colorPro" href="<?php echo e(route('producto',$producto->id)); ?>"><?php echo $producto->{'titulo_'.$idioma}; ?></a>
                                </ul>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col l9">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col s12 l4">
                    <div class="card z-depth-0">
                        <div class="card-image center-align">
                            <a href="<?php echo e(route('producto', $producto->id)); ?>">
                                <div class="efecto">
                                    <span class="central"><i class="material-icons">add</i></span>
                                </div>
                                <div style="display: flex; justify-content: center; align-items: center;">
                                <div class="caption" style="position: absolute; z-index: 99; top: 25%;">
                                <img src="<?php echo e(asset('img/copyright.png')); ?>" style="opacity: 0.5;">
                                </div>
                                </div>
                                <?php if(File::exists(public_path('img/productos/'.$producto->imagen))): ?>
                                <img src="<?php echo e(asset('img/productos/'.$producto->imagen)); ?>" style="border: 1px solid #DDD; width: 100%; height: 100%;">
                                <?php else: ?>
                                <img src="<?php echo e(asset('img/copyright.png')); ?>" style="border: 1px solid #DDD; width: 100%; height: 100%;">
                                <?php endif; ?>
                            </a>
                        </div>
                        <div class="card-content cero center-align " style=" height: 100px; display:flex; justify-content: center; align-items:center;">
                            <div class=" fw5 fs16 gris13"><?php echo $producto->{'titulo_'.$idioma}; ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).ready(function() {
        $('.datepicker').datepicker({
            format: 'dd-mm-yyyy',
            selectYears: 200,
            min: new Date(2018, 11, 23),
            max: new Date(2080, 12, 31)
        });
    });

    $(document).ready(function() {
        $('select').formSelect();
    });
</script>
