<?php $__env->startSection('titulo', 'Editar Producto'); ?>

<?php $__env->startSection('cuerpo'); ?>

<main>
	<div class="container fullwidth">
		<?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo $error; ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>
		<div class="row">
			<div class="col s12">
				<?php echo Form::model($producto, ['route'=>['producto.update', $producto->id], 'method'=>'PUT', 'files' => true]); ?>

				<div class="row">
					
				</div>
				<div class="row">
					<div class="file-field input-field col s6">
						<?php echo Form::label('Categoria'); ?><br />
						<?php echo Form::select('id_categoria', $categoria, null, ['class' => 'form-control', 'required']); ?>

					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Orden'); ?>

						<?php echo Form::text('orden',$producto->orden,['class'=>'validate', 'required']); ?>

					</div>
				</div>

				<div class="row">
					<div class="file-field input-field col s6">
						<div class="btn">
							<span>Imagen</span>
							<?php echo Form::file('imagen'); ?>

						</div>
						<div class="file-path-wrapper">
							<?php echo Form::text('',$producto->imagen, ['class'=>'file-path validate', 'required']); ?>

						</div>
					</div>
					<div class="file-field input-field col s6">
						<div class="btn">
							<span>Plano</span>
							<?php echo Form::file('plano'); ?>

						</div>
						<div class="file-path-wrapper">
							<?php echo Form::text('',$producto->plano, ['class'=>'file-path validate']); ?>

						</div>
					</div>
				</div>

				<div class="row">
					<div class="input-field col s4">
						<?php echo Form::label('Titulo Español'); ?>

						<?php echo Form::text('titulo_es',$producto->titulo_es, ['class'=>'validate']); ?>

					</div>
					<div class="input-field col s4">
						<?php echo Form::label('Titulo English'); ?>

						<?php echo Form::text('titulo_en',$producto->titulo_en, ['class'=>'validate']); ?>

					</div>
					<div class="input-field col s4">
						<?php echo Form::label('Titulo Portugues'); ?>

						<?php echo Form::text('titulo_br',$producto->titulo_br, ['class'=>'validate']); ?>

					</div>
				</div>

				

				<div class="row">
					<div class="input-field col s4">
						<div><?php echo Form::label('Texto Español'); ?></div>
						<?php echo Form::textarea('texto_es',$producto->texto_es, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

					</div>
					<div class="input-field col s4">
						<div><?php echo Form::label('Texto English'); ?></div>
						<?php echo Form::textarea('texto_en',$producto->texto_en, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

					</div>
					<div class="input-field col s4">
						<div><?php echo Form::label('Texto Portugues'); ?></div>
						<?php echo Form::textarea('texto_br',$producto->texto_br, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

					</div>
				</div>

				<div class="col s12 no-padding">
					<?php echo Form::submit('Guardar', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</main>
<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>
	CKEDITOR.replace('texto_es');
	CKEDITOR.replace('texto_en');
	CKEDITOR.replace('texto_br');
	CKEDITOR.config.width = '100%';
</script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="<?php echo e(asset('plugins/materialize/js/materialize.min.js')); ?>"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$('select').formSelect();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>