<!-- Bootstrap Core CSS -->
<link href="<?php echo e(asset('css/materialize/materialize.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

<!--Import Google Icon Font-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700" rel="stylesheet">

<!-- Compiled and minified CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">

<link rel="icon" href="<?php echo e(asset('img/logos/'.$favicon->imagen)); ?>" type="image/x-icon">
<link rel="shortcut icon" href="<?php echo e(asset('img/logos/'.$favicon->imagen)); ?>" type="image/x-icon">
<link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet">


<style>
    .datepicker-date-display {
        background-color: #D16243;
    }
</style>

