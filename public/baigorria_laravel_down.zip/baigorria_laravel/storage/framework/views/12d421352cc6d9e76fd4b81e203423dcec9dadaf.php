<div class="slider" >
<ul class="slides" >
<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li style="border-bottom: 0;">
        <img src="<?php echo e(asset('img/sliders/'.$slider->imagen)); ?>">
        <div class="caption center-align" style="background: inherit;">
        	<div class="hide-on-med-and-down">
        		<h3 class="fc5 lts center-align fs28"><?php echo $slider->titulo; ?></h3>
	            <h4 class="fc5 lts fw7 fs36"><?php echo $slider->subtitulo; ?></h4>
            </div>
        	<div class="hide-on-large-only">
        		<h3 class="fc5 lts center-align"><?php echo $slider->titulo; ?></h3>
	            <h4 class="fc5 lts fw7"><?php echo $slider->subtitulo; ?></h4>
            </div>            
        </div>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>