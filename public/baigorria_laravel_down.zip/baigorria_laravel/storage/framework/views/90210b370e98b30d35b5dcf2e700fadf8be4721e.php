<?php $__env->startSection('titulo', 'Editar Iconos'); ?>

<?php $__env->startSection('cuerpo'); ?>
<main>
	<div class="container fullwidth">
		<?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo $error; ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
				<table class="highlight bordered">
					<thead>
						<td>Imagen</td>
						<td>Titulo Español</td>
						<td>Orden</td>
						<td class="text-right">Acciones</td>
					</thead>
					<tbody>
						<?php $__currentLoopData = $var; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><img src="<?php echo e(asset('img/iconos/'.$dato->imagen)); ?>" style="height: 80px;"></td>
							<td><span><?php echo $dato->titulo_es; ?></span></td>
							<td><span><?php echo $dato->orden; ?></span></td>
							<td class="text-right">
								<a href="<?php echo e(route('iconos.edit',$dato->id)); ?>"><i class="material-icons">create</i></a>
								<?php echo Form::open(['class'=>'en-linea', 'route'=>['iconos.destroy', $dato->id], 'method' => 'DELETE']); ?>

								<button type="submit" class="submit-button">
									<i class="material-icons red-text">cancel</i>
								</button>
								<?php echo Form::close(); ?>

							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
<style type="text/css">

</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>