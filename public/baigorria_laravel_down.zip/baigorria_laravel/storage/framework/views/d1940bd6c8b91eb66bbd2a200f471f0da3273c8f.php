<?php $__env->startSection('titulo', 'Editar destacado'); ?>

<?php $__env->startSection('cuerpo'); ?>

<main>
	<div class="container">
		<?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo $error; ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
				<?php echo Form::model($destacado, ['route'=>['destacado.update', $destacado->id], 'method'=>'PUT', 'files' => true]); ?>

				<div class="row">
					<div class="input-field col s8">
						<?php echo Form::label('Ruta'); ?>

						<?php echo Form::text('ruta',$destacado->ruta,['class'=>'validate']); ?>

					</div>
					<div class="input-field col s4 hide">
						<?php echo Form::label('Seccion'); ?>

						<?php echo Form::text('seccion',$destacado->seccion,['class'=>'validate']); ?>

					</div>
				</div>

				<div class="row">
					<div class="file-field input-field col s8">
						<div class="btn">
							<span>Imagen</span>
							<?php echo Form::file('imagen'); ?>

						</div>
						<div class="file-path-wrapper">
							<?php echo Form::text('',$destacado->imagen, ['class'=>'file-path validate', 'placeholder'=>'Recomendado (764 X 270)(372 X 268) Pixels']); ?>

						</div>
					</div>
					<div class="input-field col s4">
						<?php echo Form::label('Orden'); ?>

						<?php echo Form::text('orden',$destacado->orden,['class'=>'validate']); ?>

					</div>
				</div>

				<div class="row">
					<div class="input-field col s12">
						<?php echo Form::label('Titulo'); ?>

						<?php echo Form::text('titulo_es',$destacado->titulo_es,['class'=>'validate']); ?>

					</div>
					<div class="input-field col s12">
						<?php echo Form::label('Texto Español'); ?>

						<?php echo Form::textarea('texto_es',$destacado->texto_es, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

					</div>
				</div>

				<div class="row">
					<div class="input-field col s12">
						<?php echo Form::label('Titulo English'); ?>

						<?php echo Form::text('titulo_en',$destacado->titulo_en,['class'=>'validate']); ?>

					</div>
					<div class="input-field col s12">
						<?php echo Form::label('Texto English'); ?>

						<?php echo Form::textarea('texto_en',$destacado->texto_en, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

					</div>
				</div>

				<div class="row">
					<div class="input-field col s12">
						<?php echo Form::label('Titulo Portugues'); ?>

						<?php echo Form::text('titulo_br',$destacado->titulo_br,['class'=>'validate']); ?>

					</div>
					<div class="input-field col s12">
						<?php echo Form::label('Texto Portugues'); ?>

						<?php echo Form::textarea('texto_br',$destacado->texto_br, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

					</div>
				</div>

				<div class="col s12 no-padding">
					<?php echo Form::submit('Guardar', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</main>
<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>
	CKEDITOR.replace('texto_es');
	CKEDITOR.replace('texto_en');
	CKEDITOR.replace('texto_br');
	CKEDITOR.config.width = '100%';
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>