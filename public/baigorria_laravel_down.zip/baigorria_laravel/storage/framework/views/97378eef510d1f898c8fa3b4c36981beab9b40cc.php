<!DOCTYPE html>

<html lang="es">

<head>
    <?php echo $__env->make('page.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('page.template.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="destacados">
        <div class="container" style="width: 80%; margin-top: 50px;">
            <div class="row">
                <?php $__currentLoopData = $destacados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destacado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo $destacado->ruta; ?>">
                    <div class="col l4 m12">
                        <div class="card">
                            <div class="cuadradas card-image">
                                <img src="<?php echo e(asset('img/destacados/'.$destacado->imagen)); ?>" style="">
                            </div>
                            <div class="card-title" style="width: 100%; padding: 25px;">
                                <div class="fcGr fw5 fs18" style="color: #595959;">
                                    <?php echo $destacado->{'titulo_'.$idioma}; ?>

                                </div>
                                <div class="fcGc fw5 fs16" style="color: #A4A3A4;">
                                    <?php echo $destacado->{'texto_'.$idioma}; ?>

                                </div>
                            </div>
                        </div>
                    </div>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>

    <section class="iconos">
        <div style="background: #00446F;">
            <div class="container" style="width:80%; margin-top: 50px; padding-top: 25px; padding-bottom: 25px;">
                <div class="row">
                    <?php $__currentLoopData = $iconos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col l4 m12" style="padding: 25px;">
                        <div class="row" style="display: flex; justify-content: center; align-items: center;">
                            <div class="col l4 m12">
                                <img src="<?php echo e(asset('img/iconos/'.$icono->imagen)); ?>">
                            </div>
                            <div class="col l8 m12 fc1">
                                <?php echo $icono->{'titulo_'.$idioma}; ?>

                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

    <section class="ziczac">
        <div class="container" style="width:82%;">
            <div class="row fs18">
                <div class="col l6" style="background: #00446F; padding: 50px;">
                    <div class="fc7"><?php echo $c1->{'titulo_'.$idioma}; ?></div>
                    <div class="fc1 fw7 fs28"><?php echo $c1->{'subtitulo_'.$idioma}; ?></div>
                    <div class="fc1"><?php echo $c1->{'texto_'.$idioma}; ?></div>
                    <br>
                </div>
                <div class="col l6 center-align">
                    <div style="margin-top: 50px;">
                        <img class="responsive-img" src="<?php echo e(asset('img/contenidos/'.$c1->imagen)); ?>">
                    </div>
                </div>
            </div>

            <div class="row fs18">
                <div class="col l6 right" style="background: #00446F; padding: 50px;">
                    <div class="fc7"><?php echo $c2->{'titulo_'.$idioma}; ?></div>
                    <div class="fc1 fw7 fs28"><?php echo $c2->{'subtitulo_'.$idioma}; ?></div>
                    <div class="fc1"><?php echo $c2->{'texto_'.$idioma}; ?></div>
                    <br>
                </div>
                <div class="col l6 center-align">
                    <div style="margin-top: 50px;">
                        <img class="responsive-img" src="<?php echo e(asset('img/contenidos/'.$c2->imagen)); ?>">
                    </div>
                </div>
            </div>

            <div class="row fs18">
                <div class="col l6" style="background: #00446F; padding: 50px;">
                    <div class="fc7"><?php echo $c3->{'titulo_'.$idioma}; ?></div>
                    <div class="fc1 fw7 fs28"><?php echo $c3->{'subtitulo_'.$idioma}; ?></div>
                    <div class="fc1"><?php echo $c3->{'texto_'.$idioma}; ?></div>
                    <br>
                </div>
                <div class="col l6 center-align">
                    <div style="">
                        <img class="responsive-img" src="<?php echo e(asset('img/contenidos/'.$c3->imagen)); ?>">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div style="background: #00446F;">
        <div class="container" style="width: 100%;">
            <section style="background-image: url('<?php echo e(asset('img/banner/'.$banner->imagen)); ?>'); background-repeat: no-repeat; background-size: cover; ">
                <div class="row">
                    <div class="col l6" style="padding: 70px;">
                        <div class="fc1 fs28">
                            <?php echo app('translator')->getFromJson('general.youtube1'); ?></div>
                            <div class="fc1 fs28">
                                <?php echo app('translator')->getFromJson('general.youtube2'); ?></div>
                                <div class="fc1 fs28"><i class="fab fa-youtube"></i></div>
                            </div>
                            <div class="col l4" style="padding: 90px; margin-left: 30px;">
                                <iframe width="408" height="240" src="https://www.youtube.com/embed/<?php echo e($banner->video); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            </div>
                        </div>
            </section>
        </div>
    </div>

    <?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).ready(function() {
        $('select').formSelect();
    });
</script>