<style media="screen">
    .formLogin {
        width: 290px !important;
    }
</style>

<header style="font-family: 'Monserrat'; margin-bottom: 0;">

    <div style="margin-bottom: 0; display: flex; justify-content: center; align-items: center;">
        

        <div class="container" style="width: 85%; ">

            <a href="#" data-target="slide-out" class="hide-on-large-only sidenav-trigger right" style="margin: 40px 0 50px 0px; padding: 0 10px 0 10px; border: 1px solid #DDDDDD"><i class="material-icons">menu</i></a>
            <div class="row" style=" margin-bottom: 0; margin-right: 0;">

                <div class="col l2">
                    <a href="<?php echo e(route('privatezone')); ?>" class="center hide-on-med-and-down" style="margin-top: 10px; margin-bottom: 10px;">
                        <img class="responsive-img" src="<?php echo e(asset('img/logos/'.$header->imagen)); ?>">
                    </a>
                    <a href="<?php echo e(route('privatezone')); ?>" class="center hide-on-large-only" style="margin-top: 10px; margin-bottom: 0px;">
                        <img class="responsive-img" src="<?php echo e(asset('img/logos/'.$header->imagen)); ?>" style="height: 100px;">
                    </a>
                </div>

                <div class="offset-l4 col l6 hide-on-med-and-down">
                    <div class="row">
                        <div>
                            <div class="offset-l2 col l8">
                                <span style="display:flex; justify-content: center; align-items: center; margin-top:5px;">
                                    <i class="material-icons" style="margin-right:3px;color: #B0B0B0">account_circle</i>
                                    <span>
                                        <?php if(Auth()->user()): ?>
                                            <span style="color: #B0B0B0">
                                                <?php echo app('translator')->getFromJson('general.bienvenido'); ?>
                                                <?php echo e(Auth()->user()->first_name); ?>

                                            </span>
                                            <a class='dropdown-trigger hoverColor' href='<?php echo e(route('adm.logoutd')); ?>'>
                                                <?php echo app('translator')->getFromJson('general.cerrar_sesion'); ?>
                                            </a>
                                            <?php else: ?>
                                            Username
                                            <?php endif; ?></span>
                                    </span>
                            </div>
                            <div class="col l2">
                                <a class='dropdown-trigger hoverColor' href='#' data-target='dropdown2' style="display: flex; justify-content: center; align-items: center; border-left: 1px solid #BBBBBB; margin-top:5px;">
                                    <span style="display:flex; justify-content: center; align-items: center; ">
                                        <span class="mayus"><?php echo e($idioma); ?></span>
                                        <i class="material-icons">expand_more</i>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="row center-align" style="margin-top:10px;">
                        <div class="col l4">
                            <a href="<?php echo e(route('catalogos')); ?>">
                                <div class="navTXT  <?php if($active == 'catalogo'): ?> navActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_catalogo'); ?></div>
                            </a>
                        </div>

                        <div class="col l3">
                            <a href="<?php echo e(route('carrito')); ?>">
                                <div class="navTXT  <?php if($active == 'carrito'): ?> navActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_carrito'); ?></div>
                            </a>
                        </div>

                        <div class="col l4">
                            <a href="<?php echo e(route('listadeprecios')); ?>">
                                <div class="navTXT  <?php if($active == 'listadeprecios'): ?> navActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_listas'); ?></div>
                            </a>
                        </div>
                        <div class="col l1 hide-on-med-and-down" style="margin-top: 8px;">
                            <a href="<?php echo e(route('buscar')); ?>" style="float: left;">
                                <div class="navICO">
                                    <i class="material-icons">search</i>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<ul id="slide-out" class="sidenav">
    <li>
        <a href="<?php echo e(route('index')); ?>">
            <div class=" <?php if($active == 'home'): ?> sideActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_homepag'); ?></div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('categorias')); ?>">
            <div class=" <?php if($active == 'productos'): ?> sideActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_product'); ?></div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('exportacion')); ?>">
            <div class=" <?php if($active == 'exportacion'): ?> sideActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_exporta'); ?></div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('calidad')); ?>">
            <div class=" <?php if($active == 'calidad'): ?> sideActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_calidad'); ?></div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('contacto')); ?>">
            <div class=" <?php if($active == 'contacto'): ?> sideActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_contact'); ?></div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('buscar')); ?>">
            <div class=" <?php if($active == 'busca'): ?> sideActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.buscador'); ?></div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('catalogos')); ?>">
            <div class=" <?php if($active == 'catalogo'): ?> sideActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_catalogo'); ?></div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('carrito')); ?>">
            <div class=" <?php if($active == 'carrito'): ?> sideActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_carrito'); ?></div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('listadeprecios')); ?>">
            <div class=" <?php if($active == 'listadeprecios'): ?> sideActive <?php endif; ?>"><?php echo app('translator')->getFromJson('general.head_listas'); ?></div>
        </a>
    </li>
    <?php if(Auth()->user()): ?>
        <li>
            <a href="<?php echo e(route('adm.logoutd')); ?>">
                <div><b>Logout</b>&nbsp;<?php echo e(Auth()->user()->user); ?></div>
            </a>
        </li>
        <?php endif; ?>
</ul>

<ul class="dropdown-content formLogin" id="dropdown1" style="background: none, width:400px!important; height: 300px!important;">
    <div class="container" style="background: white; margin-top: 19px !important; outline: none; width: 282px!important;">
        
        <div class="input-field col s12" style="padding-left: 10px; margin: 2px; margin-top: 1px; margin-bottom: 9px;">
            <?php echo Form::text('username',null,['class'=>'', 'required', 'autocomplete' => 'off']); ?>

            <label for="username" style="color:gray; font-weight: 500; font-size: 15px;">
                <?php echo app('translator')->getFromJson('general.form_user'); ?>
            </label>
        </div>
        <div class="input-field col s12" placeholder="password" style="padding-left: 10px; margin: 2px;">
            <?php echo Form::password('password',null,['class'=>'', 'required', 'style'=>'border-bottom:0;']); ?>

            <label for="password" style="color:gray; font-weight: 500; font-size: 15px;">
                <?php echo app('translator')->getFromJson('general.form_pass'); ?>
            </label>
        </div>
        <style type="text/css">
            .color-del-boton {
                background-color: #01A0E2;
            }

            .color-del-boton:hover {
                background-color: #01A0E2;
            }
        </style>
        <div class="col s12" style="position: relative; right: 30%;margin-top: 9%;margin-bottom: 2%;">
            <input class="waves-effect waves-light btn right colorboton z-depth-0" style="color: white;font-weight: bold; background: #009688!important;" type="submit" value="<?php echo app('translator')->getFromJson('general.form_join'); ?>">
            <a href="<?php echo e(route('catalogos')); ?>" class="waves-effect waves-light btn right colorboton z-depth-0">INGRESAR</a>

        </div>
        <li class="center" style="font-size: 12px;color: pink; text-decoration: none;">
            <a href="<?php echo e(url('registro')); ?>" style="color: #2962E8!important; text-align: center;">
                <?php echo app('translator')->getFromJson('general.form_new'); ?>
            </a>
        </li>
        
    </div>
</ul>

<!-- Dropdown Structure -->
<ul id='dropdown2' class='dropdown-content'>
    <li><a href="<?php echo e(url('idioma/es')); ?>">ES</a></li>
    <li><a href="<?php echo e(url('idioma/en')); ?>">EN</a></li>
    <li><a href="<?php echo e(url('idioma/br')); ?>">BR</a></li>
</ul>

<div style="position: fixed;bottom: 0px;right: 10%;padding: 10px;background: #00456D; color: white;text-align: center; width: 250px; z-index: 999999;">
    <div class="row">
        <div class="col l5 left-align">
            <a href="<?php echo e(asset('img/catalogo-esparragos.pdf')); ?>" target="_blank" class="fc1">
                <div>Descarga</div>
                <div><b>el&nbsp;Catálogo</b></div>
            </a>
        </div>
        <div class="col l7">
            <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($red->link); ?>" style="float: left; margin-top: 10px; margin-right: 5px; margin-left: 5px;" target="_blank">
                <div class="fc1">
                    <i class="<?php echo e($red->icono); ?>" style="font-size: 20px;"></i>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</div>