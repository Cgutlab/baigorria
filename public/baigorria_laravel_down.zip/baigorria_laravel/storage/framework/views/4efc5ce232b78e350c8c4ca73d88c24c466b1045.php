<?php $__env->startSection('titulo', 'Crear Presentacion'); ?>

<?php $__env->startSection('cuerpo'); ?>

<main>
	<div class="container fullwidth">
		<?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo $error; ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
				<?php echo Form::open(['route'=>'presentacion.store', 'method'=>'POST', 'files' => true]); ?>

				<div class="row">
					
				</div>

				<div class="row">
					<div class="input-field col s4">
						<select name="id_producto" required>
							<?php $__currentLoopData = $selectCategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectCategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<optgroup label="<?php echo e($selectCategoria->titulo_es); ?>">
								<?php $__currentLoopData = $selectProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($selectProducto->id_categoria == $selectCategoria->id): ?>
									<option value="<?php echo e($selectProducto->id); ?>"><?php echo e($selectProducto->titulo_es); ?></option>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</optgroup>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<label>Producto</label>
					</div>
					<div class="input-field col s4">
						<?php echo Form::label('Precio'); ?>

						<?php echo Form::number('precio',null,['class'=>'validate', 'step' => 'any']); ?>

					</div>
					<div class="input-field col s4">
						<?php echo Form::label('Orden'); ?>

						<?php echo Form::text('orden',null,['class'=>'validate', 'required']); ?>

					</div>
				</div>

				<div class="row">
					<div class="input-field col l2 s4">
						<?php echo Form::label('Precio A'); ?>

						<?php echo Form::number('precio_a',null,['class'=>'validate', 'step' => 'any']); ?>

					</div>
					<div class="input-field col l2 s4">
						<?php echo Form::label('Precio B'); ?>

						<?php echo Form::number('precio_b',null,['class'=>'validate', 'step' => 'any']); ?>

					</div>
					<div class="input-field col l2 s4">
						<?php echo Form::label('Precio C'); ?>

						<?php echo Form::number('precio_c',null,['class'=>'validate', 'step' => 'any']); ?>

					</div>
					<div class="input-field col l2 s4">
						<?php echo Form::label('Precio D'); ?>

						<?php echo Form::number('precio_d',null,['class'=>'validate', 'step' => 'any']); ?>

					</div>
					<div class="input-field col l2 s4">
						<?php echo Form::label('Precio E'); ?>

						<?php echo Form::number('precio_e',null,['class'=>'validate', 'step' => 'any']); ?>

					</div>
					<div class="input-field col l2 s4">
						<?php echo Form::label('Precio F'); ?>

						<?php echo Form::number('precio_f',null,['class'=>'validate', 'step' => 'any']); ?>

					</div>
				</div>

				<div class="row">
					<div class="input-field col s4">
						<?php echo Form::label('Titulo Español'); ?>

						<?php echo Form::text('titulo_es',null, ['class'=>'validate']); ?>

					</div>
					<div class="input-field col s4">
						<?php echo Form::label('Titulo English'); ?>

						<?php echo Form::text('titulo_en',null, ['class'=>'validate']); ?>

					</div>
					<div class="input-field col s4">
						<?php echo Form::label('Titulo Portugues'); ?>

						<?php echo Form::text('titulo_br',null, ['class'=>'validate']); ?>

					</div>
				</div>

				<div class="row">
					<div class="input-field col s6">
						<?php echo Form::label('Codigo Presentacion'); ?>

						<?php echo Form::text('codigo',null,['class'=>'validate', 'required']); ?>

					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Codigo OEM'); ?>

						<?php echo Form::text('oem',null,['class'=>'validate']); ?>

					</div>
				</div>

				<div class="row">
					<div class="file-field input-field col s6">
						<div class="btn">
							<span>Ficha</span>
							<?php echo Form::file('ficha'); ?>

						</div>
						<div class="file-path-wrapper">
							<?php echo Form::text('',null, ['class'=>'file-path validate']); ?>

						</div>
					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Tipo/type'); ?>

						<?php echo Form::text('tipo',null,['class'=>'validate']); ?>

					</div>
				</div>

				<div class="row">
					<div class="input-field col s6">
						<?php echo Form::label('Marca'); ?>

						<?php echo Form::text('marca',null,['class'=>'validate']); ?>

					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Modelo'); ?>

						<?php echo Form::text('modelo',null,['class'=>'validate']); ?>

					</div>
				</div>

				<div class="center-align">
					<table class="highlight bordered responsive-table">
						<tbody>
							<tr>
								<td>
									<?php echo Form::label('ø "A" PASO'); ?>

									<?php echo Form::text('medida_a',null,['class'=>'validate']); ?>

								</td>
								<td>
									<?php echo Form::label('Hexágono "B" .mm'); ?>

									<?php echo Form::text('medida_b',null,['class'=>'validate']); ?>

								</td>
								<td>
									<?php echo Form::label('Altura "C" .mm'); ?>

									<?php echo Form::text('medida_c',null,['class'=>'validate']); ?>

								</td>
								<td>
									<?php echo Form::label('D'); ?>

									<?php echo Form::text('medida_d',null,['class'=>'validate']); ?>

								</td>
								<td>
									<?php echo Form::label('"E" DIÁMETRO Y PASO'); ?>

									<?php echo Form::text('medida_e',null,['class'=>'validate']); ?>

								</td>
								<td>
									<?php echo Form::label('F'); ?>

									<?php echo Form::text('medida_f',null,['class'=>'validate']); ?>

								</td>
								<td>
									<?php echo Form::label('G'); ?>

									<?php echo Form::text('medida_g',null,['class'=>'validate']); ?>

								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="row">
					<div class="input-field col s6">
						<?php echo Form::label('Dureza'); ?>

						<?php echo Form::text('dureza',null,['class'=>'validate']); ?>

					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Terminacion'); ?>

						<?php echo Form::text('terminacion',null,['class'=>'validate']); ?>

					</div>
				</div>

				<div class="row">
					<div class="file-field input-field col s6">
						<div class="btn">
							<span>Imagen1</span>
							<?php echo Form::file('imagen1'); ?>

						</div>
						<div class="file-path-wrapper">
							<?php echo Form::text('',null, ['class'=>'file-path validate']); ?>

						</div>
					</div>
					<div class="file-field input-field col s6">
						<div class="btn">
							<span>Imagen2</span>
							<?php echo Form::file('imagen2'); ?>

						</div>
						<div class="file-path-wrapper">
							<?php echo Form::text('',null, ['class'=>'file-path validate']); ?>

						</div>
					</div>
					<div class="file-field input-field col s6">
						<div class="btn">
							<span>Imagen3</span>
							<?php echo Form::file('imagen3'); ?>

						</div>
						<div class="file-path-wrapper">
							<?php echo Form::text('',null, ['class'=>'file-path validate']); ?>

						</div>
					</div>
					<div class="file-field input-field col s6">
						<div class="btn">
							<span>Imagen4</span>
							<?php echo Form::file('imagen4'); ?>

						</div>
						<div class="file-path-wrapper">
							<?php echo Form::text('',null, ['class'=>'file-path validate']); ?>

						</div>
					</div>
				</div>


				

				<div class="row">
					<div class="input-field col s4">
						<div><?php echo Form::label('Cantidad Por Caja'); ?></div>
						<?php echo Form::number('cantidadxcaja',null, ['class'=>'validate']); ?>

					</div>
				</div>

				<div class="col s12 no-padding">
					<?php echo Form::submit('Guardar', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>

			</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
	</div>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="<?php echo e(asset('plugins/materialize/js/materialize.min.js')); ?>"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$('select').formSelect();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>