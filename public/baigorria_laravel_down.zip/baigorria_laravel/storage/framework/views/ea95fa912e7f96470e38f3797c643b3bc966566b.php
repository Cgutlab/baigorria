<!DOCTYPE html>

<html lang="es">

<head>
    <?php echo $__env->make('privada.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('privada.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('privada.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div style="background: #00446F; margin-bottom: 45px;">
        <section style="padding: 50px; background-image: url('<?php echo e(asset('img/banner/'.$banner->imagen)); ?>'); background-repeat: no-repeat; background-size: cover; ">
            <div class=" container" style="width:100%;">
                <div class="align-center">
                    <div class="fc1 fs20">
                        <div class="container">
                            <nav class="z-depth-0" style="">
                                <div class="nav-wrapper z-depth-0">
                                    <?php echo Form::open(['route'=>'catalogo', 'method' => 'POST']); ?>

                                    <div class="input-field" style="background: white; border: 1px solid gray;">
                                        <input id="busqueda" name="busqueda" type="search" placeholder="<?php echo $banner->{'titulo_'.$idioma}; ?>" required>
                                        <label class="label-icon" for="search"><i class="material-icons" style="color: #AFAFAF; font-weight: 600;">search</i></label>
                                        <i class="material-icons azul" style="color: #3E4EB8;">chevron_right</i>
                                    </div>
                                    <?php echo Form::close(); ?>

                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div class="row" style=" margin-bottom: 45px;">
        <div class="container" style="width:100%;">

            <?php if(count($errors) > 0): ?>
            <div class="col s12 card-panel red lighten-4 red-text text-darken-4">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo $error; ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
            <div class="col s12 card-panel red lighten-4 red-text text-darken-4  center-align">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <table class="highlight bordered responsive-table centered">
                <thead>
                    <tr class="fc15 fw5">
                        <td></td>
                        <td>Código</td>
                        <td>Categoría</td>
                        <td>Descripción</td>
                        <td style="text-align: center;">Modelo</td>
                        <td></td>
                        <td style="width: 30px;text-align: center;">Precio Unitario $</td>
                        <td>Cantidad</td>
                        <td style="width: 30px;text-align: center;">Cantidad por caja</td>
                        <td>Unidades</td>
                        <td style="width: 30px;text-align: center;">Subtotal $</td>
                        <td></td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $presentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presentaciones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo Form::open(['route'=>'carrito.add','METHOD'=>'POST']); ?>

                    <tr>
                        <td>
                            <?php if($presentaciones->imagen1): ?>
                                <div><img src="<?php echo e(asset('img/presentaciones/'.$presentaciones->imagen1)); ?>" style="width:60px;"></div>
                                <?php elseif($presentaciones->imagen2): ?>
                                    <div><img src="<?php echo e(asset('img/presentaciones/'.$presentaciones->imagen2)); ?>" style="width:60px;"></div>
                                    <?php elseif($presentaciones->imagen3): ?>
                                        <div><img src="<?php echo e(asset('img/presentaciones/'.$presentaciones->imagen3)); ?>" style="width:60px;"></div>
                                        <?php elseif($presentaciones->imagen4): ?>
                                            <div><img src="<?php echo e(asset('img/presentaciones/'.$presentaciones->imagen4)); ?>" style="width:60px;"></div>
                                            <?php else: ?>
                                            <div><img src="<?php echo e(asset('img/productos/'.$presentaciones->productos->imagen)); ?>" style="width:60px;"></div>
                                            <?php endif; ?>
                        </td>
                        <td style="text-align: left;">
                            <b><?php echo $presentaciones->codigo; ?></b>
                            <div><input type="hidden" value="<?php echo e($presentaciones->id); ?>" name="id_presentacion"></div>
                        </td>
                        <td style="text-align: left;"><?php echo $presentaciones->productos->{'titulo_'.$idioma}; ?></td>
                        <td style="text-align: left;"><?php echo $presentaciones->{'titulo_'.$idioma}; ?></td>
                        <td><?php echo $presentaciones->terminacion; ?></td>
                        <td>
                            <?php if($presentaciones->ficha): ?>
                                <a href="<?php echo e(asset('img/fichas/'.$presentaciones->ficha)); ?>" target="_blank" class="boton" style="padding-left:5px!important; padding-right:5px!important;">FICHA&nbsp;TÉCNICA</a>
                                <?php endif; ?>
                        </td>
                        <td>
                            <div>
                                <?php
                                if($presentaciones->productos->categorias->id === 1){
                                $asignado = 'precio_'.Auth()->user()->precio_esparragos;
                                $precio = $presentaciones->$asignado;
                                }
                                if($presentaciones->productos->categorias->id === 2){
                                $asignado = 'precio_'.Auth()->user()->precio_bulones;
                                $precio = $presentaciones->$asignado;
                                }
                                if($presentaciones->productos->categorias->id === 6){
                                $asignado = 'precio_'.Auth()->user()->precio_especial;
                                $precio = $presentaciones->$asignado;
                                }
                                ?>
                                <?php echo e($precio); ?>


                            </div>
                        </td>
                        <td>
                            <?php
                            $cantidad = '0';
                            $subtotal = '-';
                            $unidades = '-';
                            ?>

                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($row->id == $presentaciones->id): ?>
                                <?php
                                $id_presentacion = $row->id;
                                $cantidad = $row->qty;
                                $precio = $precio;
                                if($presentaciones->cantidadxcaja){
                                $unidades = $presentaciones->cantidadxcaja * $row->qty;
                                }else{
                                $unidades = $row->qty;
                                }
                                $subtotal = $precio * $unidades;
                                ?>
                                <div><input type="hidden" value="<?php echo e($row->id); ?>" name="id_presentacion" style=""></div>
                                <div><input type="hidden" value="<?php echo e($row->rowId); ?>" name="id_carrito" style=""></div>
                                <div><input type="hidden" value="<?php echo e($precio); ?>" name="id_precio" style=""></div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div><input type="number" value="<?php echo e($cantidad); ?>" name="cantidad" style="width: 52px; height: 35px; border: 1px solid #ECECEC; border-radius: 4px; padding-left: 5px; background: #F8F8F8; box-shadow: none;" required></div>
                        </td>
                        <td>
                            <?php if($presentaciones->cantidadxcaja): ?>
                                <?php echo $presentaciones->cantidadxcaja; ?>

                                <?php else: ?>
                                <?php echo e('-'); ?>

                                <?php endif; ?>
                        </td>
                        <td>
                            <div><input type="hidden" value="<?php echo e($precio); ?>" name="id_precio" style=""></div>
                            <?php echo e($unidades); ?>

                        </td>
                        <td><?php echo e($subtotal); ?></td>
                        <td>
                            <div style="display:flex; justify-content:center; align-items: center;">
                                <?php if($precio): ?>
                                <button type="submit" href="" style="color:#A2A2A2; border:0; background: inherit; width: 120px; display:flex; justify-content: center; align-items: center;">
                                    <?php if($unidades == '-'): ?>
                                    <i class="material-icons">add_shopping_cart</i>
                                    <span>Comprar</span>
                                    <?php else: ?>
                                    <i class="material-icons verde2">check_circle</i>
                                    <?php endif; ?>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php echo Form::close(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- <a href="<?php echo e(route('carrito.destroy')); ?>" class="boton">Destroy</a> -->
        </div>
    </div>

    <?php echo $__env->make('privada.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('privada.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $("[name='record']").on("change", function(e) {
        let edit_id = $(this).val();
        window.location.href = edit_id;
    });

    $("#cantidad").change(function() {
        let cantidad = $(this).val();
        let precio = $("#input_precio").val();

        $('#precio').html("$" + (cantidad * precio).toFixed(2));
    });

    $(document).ready(function() {
        $('select').formSelect();
    });
</script>