<?php $__env->startSection('titulo', 'Crear Red Social'); ?>

<?php $__env->startSection('cuerpo'); ?>

<main>
	<div class="container">
		<?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo $error; ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
				<?php echo Form::open(['route'=>'redes.store', 'method'=>'POST', 'files' => true]); ?>

				
				<div class="row">
					<div class="input-field col s12">
						<?php echo Form::label('Codigo Icon'); ?>

						<?php echo Form::text('icono',null,['class'=>'validate', 'required']); ?>

					</div>
					<small>
						Lista de iconos: <a href="https://fontawesome.com/icons?d=gallery" target="_blank">https://fontawesome.com/icons?d=gallery</a>
						<br>
						Solo debes insertar el código Ejemplo: <i class="fab fa-accessible-icon"></i> >> <b>fab fa-accessible-icon</b>
					</small>
				</div>
				<div class="row">
					<div class="input-field col s12">
						<?php echo Form::label('Link'); ?>

						<?php echo Form::text('link',null,['class'=>'validate', 'required']); ?>

					</div>
				</div>
				<div class="row">
					<div class="input-field col s8">
						<?php echo Form::label('Titulo'); ?>

						<?php echo Form::text('titulo',null,['class'=>'validate', 'required']); ?>

					</div>
					<div class="input-field col s4">
						<?php echo Form::label('Orden'); ?>

						<?php echo Form::text('orden',null,['class'=>'validate', 'required']); ?>

					</div>
				</div>
				<div class="col s12 no-padding">
					<?php echo Form::submit('Crear', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>