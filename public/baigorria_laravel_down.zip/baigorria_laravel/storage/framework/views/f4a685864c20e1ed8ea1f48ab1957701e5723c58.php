<script type="text/javascript">
function confirm_delete() {
var result = confirm('¡Esto es irreversible! ¿Esta seguro que desea eliminar?');
if (result) {
        return true;
    } else {
        return false;
    }
}
</script>
