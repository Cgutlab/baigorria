<?php $__env->startSection('content'); ?>
<?php $cont = 0;
?>

<style>
* {

    font-family: 'Montserrat';

}
</style>

<div align="center">
    
    <h2>
        <?php echo app('translator')->getFromJson('general.head_listas'); ?>
    </h2>
    <h4 style="float: left;">
        <?php
        echo date('d/m/Y')
        ?>
    </h4>
</div>

<table style="border: 1px solid gray; width: 100%;">
    <thead>
        <tr>
            
            <td>
                <?php echo app('translator')->getFromJson('general.tabla_code'); ?></td>
            <td>
                <?php echo app('translator')->getFromJson('general.tabla_text'); ?></td>
            <td>
                <?php echo app('translator')->getFromJson('general.head_product'); ?></td>
            <td>
                <?php echo app('translator')->getFromJson('general.tabla_precio'); ?></td>
            <td>
                <?php echo app('translator')->getFromJson('general.tabla_aaaa'); ?></td>
            <td>
                <?php echo app('translator')->getFromJson('general.tabla_bbbb'); ?></td>
            <td>
                <?php echo app('translator')->getFromJson('general.tabla_cccc'); ?></td>
            <td>
                <?php echo app('translator')->getFromJson('general.tabla_dddd'); ?></td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $presentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presentaciones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $cont++
        ?>
        <tr style="<?php if($cont % 2): ?> background: #FAFAFA <?php endif; ?>">
            
                            <td><?php echo $presentaciones->codigo; ?></td>
                            <td><?php echo $presentaciones->productos->{'titulo_'.$idioma}; ?></td>
                            <td><?php echo $presentaciones->{'titulo_'.$idioma}; ?></td>
                            <td>
                                <?php
                                if($presentaciones->productos->categorias->id === 1){
                                $asignado = 'precio_'.Auth()->user()->precio_esparragos;
                                $precio = $presentaciones->$asignado;
                                }
                                if($presentaciones->productos->categorias->id === 2){
                                $asignado = 'precio_'.Auth()->user()->precio_bulones;
                                $precio = $presentaciones->$asignado;
                                }
                                if($presentaciones->productos->categorias->id === 6){
                                $asignado = 'precio_'.Auth()->user()->precio_especial;
                                $precio = $presentaciones->$asignado;
                                }
                                ?>
                                <?php if($precio): ?>
                                $
                                <?php echo e($precio); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo $presentaciones->medida_a; ?></td>
                            <td><?php echo $presentaciones->medida_b; ?></td>
                            <td><?php echo $presentaciones->medida_c; ?></td>
                            <td><?php echo $presentaciones->terminacion; ?></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>