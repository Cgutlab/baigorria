<?php $__env->startSection('content'); ?>
    <?php $cont = 0; ?>
    <div align="center">
    <h2><?php echo app('translator')->getFromJson('general.head_listas'); ?></h2>
    <table style="border: 1px solid gray;">
        <thead>
            <tr>
                
                <td style="padding-right: 50px;"><?php echo app('translator')->getFromJson('general.tabla_code'); ?></td>
                <td style="padding-right: 100px;"><?php echo app('translator')->getFromJson('general.tabla_text'); ?></td>
                <td style="padding-right: 10px;"><?php echo app('translator')->getFromJson('general.tabla_aaaa'); ?></td>
                <td style="padding-right: 10px;"><?php echo app('translator')->getFromJson('general.tabla_bbbb'); ?></td>
                <td style="padding-right: 10px;"><?php echo app('translator')->getFromJson('general.tabla_cccc'); ?></td>
                <td><?php echo app('translator')->getFromJson('general.tabla_dddd'); ?></td>
            </tr>                            
        </thead>
        <tbody>
            <?php $__currentLoopData = $presentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presentaciones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $cont++ ?>
            <tr style="<?php if($cont % 2): ?> background: #FAFAFA <?php endif; ?>">
                
                <td><?php echo $presentaciones->codigo; ?></td>
                <td><?php echo $presentaciones->{'titulo_'.$idioma}; ?></td>
                <td><?php echo $presentaciones->medida_a; ?></td>
                <td><?php echo $presentaciones->medida_b; ?></td>
                <td><?php echo $presentaciones->medida_c; ?></td>
                <td><?php echo $presentaciones->terminacion; ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>