<!DOCTYPE html>

<html lang="es">

<head>
    <?php echo $__env->make('page.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div style="background: #00446F;">
        <section style="background-image: url('<?php echo e(asset('img/banner/'.$banner->imagen)); ?>'); background-repeat: no-repeat; background-size: cover; ">
            <div class="container" style="width:100%;">
                <div class="row">
                    <div class="col s12" style="padding: 70px;">
                        <div class="fc1 fs20"><?php echo $banner->{'titulo_'.$idioma}; ?></div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div class="container" style="width:100%;">
        <div class="row center-align mt15">
            <div class="fcAzul2 fs26 fw5"><?php echo $contenido1->{'titulo_'.$idioma}; ?></div>
            <div class="container fcGris2 fs20 fw4" style="width: 40%;"><?php echo $contenido1->{'texto_'.$idioma}; ?></div>
        </div>
        <div class="row mt15">
            <div class="col s12 l4">
                <div class="container">
                    <div class="calidadDestacado"><?php echo $destacado1->{'texto_'.$idioma}; ?></div>
                </div>
                <div class="container">
                    <div class="calidadDestacado"><?php echo $destacado3->{'texto_'.$idioma}; ?></div>
                </div>
            </div>
            <div class="col s12 l4 center-align">
                <img src="<?php echo e(asset('img/contenidos/'.$contenido1->imagen)); ?>" style="">
            </div>
            <div class="col s12 l4">
                <div class="container">
                    <div class="calidadDestacado"><?php echo $destacado2->{'texto_'.$idioma}; ?></div>
                </div>
                <div class="container">
                    <div class="calidadDestacado"><?php echo $destacado4->{'texto_'.$idioma}; ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="container" style="width:82%; margin-top: 35px;">
        <div class="row">
            <div class="col l6">
                <div class="fcGris1 fs17 fw4"><?php echo $contenido2->{'texto_'.$idioma}; ?></div>
            </div>
            <div class="col l6">
                <div class="fcAzul2 fs26 fw5 mt15"><?php echo $contenido2->{'titulo_'.$idioma}; ?></div>
                <div class="mt15"><img src="<?php echo e(asset('img/contenidos/'.$contenido2->imagen)); ?>" style=""></div>
            </div>
        </div>
    </div>

    <div class="container" style="width: 82%;">
        <div class="row">
            <?php $__currentLoopData = $certificado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col l6 mb15">
                <div class="calidadCertificado">
                    <div class="row">
                        <div class="col l10">
                            <div class="fw5"><?php echo $certificados->{'titulo_'.$idioma}; ?></div>
                            <div class="fw4"><?php echo app('translator')->getFromJson('general.certificados'); ?></div>
                        </div>
                        <div class="col l2 center-align" style="margin-top:10px;">
                            <a href="<?php echo 'img/certificados/'.$certificados->ficha; ?>" style="color: white;" target="_blank">
                              <i class="material-icons">file_download</i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <section class="ziczac">
        <div style="background: #00446F;">
            <div class="container" style="width:82%;">
                <?php $__currentLoopData = $articulo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $cont++
                ?>
                <?php if($cont%2): ?>
                <div class="row fs18">
                    <div class="col l6" style="padding-top:25px;">
                        <div class="fc7"><?php echo $articulos->{'titulo_'.$idioma}; ?></div>
                        <div class="fc1 fw7 fs28"><?php echo $articulos->{'subtitulo_'.$idioma}; ?></div>
                        <div class="fc1"><?php echo $articulos->{'texto_'.$idioma}; ?></div>
                        <br>
                    </div>
                    <div class="col l6 center-align">
                        <img class="responsive-img" src="<?php echo e(asset('img/articulos/'.$articulos->imagen)); ?>">
                    </div>
                </div>
                <?php else: ?>
                <div class="row fs18">
                    <div class="col l6 right" style="padding-top:25px;">
                        <div class="fc7"><?php echo $articulos->{'titulo_'.$idioma}; ?></div>
                        <div class="fc1 fw7 fs28"><?php echo $articulos->{'subtitulo_'.$idioma}; ?></div>
                        <div class="fc1"><?php echo $articulos->{'texto_'.$idioma}; ?></div>
                        <br>
                    </div>
                    <div class="col l6 center-align">
                        <img class="responsive-img" src="<?php echo e(asset('img/articulos/'.$articulos->imagen)); ?>">
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).ready(function() {
        $('.datepicker').datepicker({
            format: 'dd-mm-yyyy',
            selectYears: 200,
            min: new Date(2018, 11, 23),
            max: new Date(2080, 12, 31)
        });
    });

    $(document).ready(function() {
        $('select').formSelect();
    });
</script>
