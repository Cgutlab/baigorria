<title>Taller Baigorria</title>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<meta name="keywords" content="<?php echo e($metadato->keyword); ?>">
<meta name="description" content="<?php echo e($metadato->texto); ?>">