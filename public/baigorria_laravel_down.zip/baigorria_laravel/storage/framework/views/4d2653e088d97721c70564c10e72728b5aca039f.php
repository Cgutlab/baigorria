<div class="carousel carousel-slider center" data-indicators="true">
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="carousel-item white-text">
        <img src="<?php echo e(asset('img/sliders/'.$slider->imagen)); ?>" alt="slider">
        <div class="box-cap">
            <div id="soloSlider" class="fc7 fs18 fw6">
                <?php echo $slider->{'titulo_'.$idioma}; ?>

            </div>
            <div id="soloSlider" class="fc1 fs18 fw4">
                <?php echo $slider->{'subtitulo_'.$idioma}; ?>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
