<!DOCTYPE html>
<html lang="es">

<head>
    <?php echo $__env->make('page.template.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div style="background: #00446F;">
        <section style="background-image: url('<?php echo e(asset('img/banner/'.$banner->imagen)); ?>'); background-repeat: no-repeat; background-size: cover; ">
            <div class="container" style="width:100%;">
                <div class="row">
                    <div class="col s12" style="padding: 70px;">
                        <div class="fc1 fs20"><?php echo $banner->{'titulo_'.$idioma}; ?></div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <section class="destacados mt15 mb15">
        <div class="container mt15" style="width: 82%;">
            <div class="row center-align">

<?php /*
                <div class="col s12">
                    <div id="visitor"></div>
                    <?= $lava->render("GeoChart","Popularity","visitor"); ?>
                </div>
*/ ?>               

                <img src="<?php echo e(asset('img/contenidos/'.$contenido->imagen)); ?>" style="">
            </div>
            <div class="row center-align">
                <div class="fcAzul2 fs24 fw5 mt15"><?php echo $contenido->{'titulo_'.$idioma}; ?></div>
            </div>
            <div class="row center-align">
                <div class="fcAzul2 fs20 fw4"><?php echo $contenido->{'subtitulo_'.$idioma}; ?></div>
            </div>
            <div class="row">
                <div class="col l6">
                    <div class="fs17 fw4 fcGris1 mt15"><?php echo $contenido->{'texto_'.$idioma}; ?></div>
                </div>
                <div class="col l6">
                    <div class="fs17 fw4 fcAzul2 mt15"><?php echo $contenido->{'texto2_'.$idioma}; ?></div>

                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).ready(function() {
        $('.datepicker').datepicker({
            format: 'dd-mm-yyyy',
            selectYears: 200,
            min: new Date(2018, 11, 23),
            max: new Date(2080, 12, 31)
        });
    });

    $(document).ready(function() {
        $('select').formSelect();
    });
</script>