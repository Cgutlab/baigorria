<!DOCTYPE html>
<html>

<body>
	<h2>Taller Baigorria</h2>

	<p>Enviado desde la web </p>
	<br>
	<br>
	<h3>Datos del contacto</h3>
	<ul>
		<li><strong>Nombre:</strong><?php echo e($nombre); ?>}}</li>
		<li><strong>Apellido:</strong><?php echo e($apellido); ?>}}</li>
		<li><strong>Correo:</strong><?php echo e($correo); ?>}}</li>
		<li><strong>Teléfono:</strong><?php echo e($telefono); ?>}}</li>
		<br>
		<br>
		<h4>Mensaje:</h4>
		<p><?php echo e($mensaje); ?></p>
	</ul>
</body>

</html>