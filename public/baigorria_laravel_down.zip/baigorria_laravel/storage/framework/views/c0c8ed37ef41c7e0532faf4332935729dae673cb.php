<header style="font-family: 'Monserrat'; margin-bottom: 0;">

<div style="margin-bottom: 0; display: flex; justify-content: center; ">
  

<div class="container" style="width: 90%;  position: absolute; background: transparent; z-index: 999;">

<a href="#" data-target="slide-out" class="hide-on-large-only sidenav-trigger right" style="margin: 40px 0 50px 0px; padding: 0 10px 0 10px; border: 1px solid #DDDDDD"><i class="material-icons">menu</i></a>
<div class="row" style=" margin-bottom: 0; margin-right: 0;">

<div class="col l5 hide-on-med-and-down">
<div class="row center-align">

  <div class="col l3">
  <a href="<?php echo e(route('cabanas')); ?>" class="blanco">
  <div class="navTXT  <?php if($active == 'cabanas'): ?> navActive <?php endif; ?>">Las Cabañas</div>
  </a>
  </div>

  <div class="col l3">
  <a href="<?php echo e(route('servicios')); ?>" class="blanco">
  <div class="navTXT  <?php if($active == 'servicios'): ?> navActive <?php endif; ?>">Servicios</div>
  </a>
  </div>

  <div class="col l3">
  <a href="<?php echo e(route('videos')); ?>" class="blanco">
  <div class="navTXT  <?php if($active == 'videos'): ?> navActive <?php endif; ?>">Videos</div>
  </a>
  </div>

</div>
</div>

<div class="col l2">
    <a href="<?php echo e(route('index')); ?>" class="center hide-on-med-and-down" style="margin-top: 40px; margin-bottom: 40px;">
      <img class="responsive-img" src="<?php echo e(asset('img/logos/'.$header->imagen)); ?>">
    </a>
    <a href="<?php echo e(route('index')); ?>" class="center hide-on-large-only" style="margin-top: 40px; margin-bottom: 0px;">
      <img class="responsive-img" src="<?php echo e(asset('img/logos/'.$header->imagen)); ?>" style="height: 80px;">
    </a>
</div>

<div class="col l5 hide-on-med-and-down">

    <div class="row center-align">
      <div class="offset-l2 col l2">
      <a href="<?php echo e(route('galerias')); ?>" class="blanco">
      <div class="navTXT  <?php if($active == 'galerias'): ?> navActive <?php endif; ?>">Galer&iacute;a</div>
      </a>
      </div>

      <div class="col l4">
      <a href="<?php echo e(route('empresa')); ?>" class="blanco">
      <div class="navTXT  <?php if($active == 'donde-estamos'): ?> navActive <?php endif; ?>">San Marcos Sierra</div>
      </a>
      </div>

      <div class="col l2">
      <a href="<?php echo e(route('contacto')); ?>" class="blanco">
      <div class="navTXT  <?php if($active == 'contacto'): ?> navActive <?php endif; ?>">Contacto</div>
      </a>
      </div>

      <div class="col l2" style="margin-top: 80px;">
        <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e($red->ruta); ?>" style="float: left; ">
          <div class="navICO">
            <i class="<?php echo e($red->icon); ?>" style="font-size: 20px;"></i>
          </div>
          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div>
</div>
</div>
</div>
</div>
</header>

  <ul id="slide-out" class="sidenav">
    <li>
      <a href="<?php echo e(route('index')); ?>" class="blanco">
      <div class=" <?php if($active == 'home'): ?> sideActive <?php endif; ?>">Home</div>
      </a>
    </li>
    <li>
      <a href="<?php echo e(route('cabanas')); ?>" class="blanco">
      <div class=" <?php if($active == 'cabanas'): ?> sideActive <?php endif; ?>">Las Cabañas</div>
      </a>
    </li>
    <li>
      <a href="<?php echo e(route('servicios')); ?>" class="blanco">
      <div class=" <?php if($active == 'servicios'): ?> sideActive <?php endif; ?>">Servicios</div>
      </a>
    </li>
    <li>
      <a href="<?php echo e(route('videos')); ?>" class="blanco">
      <div class=" <?php if($active == 'videos'): ?> sideActive <?php endif; ?>">Videos</div>
      </a>
    </li>
    <li>
      <a href="<?php echo e(route('galerias')); ?>" class="blanco">
      <div class=" <?php if($active == 'galerias'): ?> sideActive <?php endif; ?>">Galeria</div>
      </a>
    </li>
    <li>
      <a href="<?php echo e(route('empresa')); ?>" class="blanco">
      <div class=" <?php if($active == 'donde-estamos'): ?> sideActive <?php endif; ?>">Donde Estamos</div>
      </a>
    </li>
    <li>
      <a href="<?php echo e(route('contacto')); ?>" class="blanco">
      <div class=" <?php if($active == 'contacto'): ?> sideActive <?php endif; ?>">Contacto</div>
      </a>
    </li>
  </ul>
