<!DOCTYPE html>
<html>

<body>
	<h2>Taller Baigorria</h2>

	<p>Enviado desde la web </p>
	<br>
	<br>
	<h3>Datos del contacto</h3>
	<ul>
		<li><strong>Nombre:</strong>{{$nombre}}}}</li>
		<li><strong>Apellido:</strong>{{$apellido}}}}</li>
		<li><strong>Correo:</strong>{{$correo}}}}</li>
		<li><strong>Teléfono:</strong>{{$telefono}}}}</li>
		<br>
		<br>
		<h4>Mensaje:</h4>
		<p>{{$mensaje}}</p>
	</ul>
</body>

</html>