<section class="contenido">

    <div class="container" style="width: 100%;">

        <div class="center-align" style=" margin-top: 35px; margin-bottom: 50px;">

            <div class="fs38 fc2">

                {!!$contenido->{'titulo_'.$idioma}!!}

            </div>

            <div class="fs22 fc6">

                {!!$contenido->subtitulo!!}

            </div>

            <div class="fs18 fc7 fw5 editorRico container" style="width: 50%;">

                {!!$contenido->texto!!}

            </div>

        </div>

    </div>

</section>