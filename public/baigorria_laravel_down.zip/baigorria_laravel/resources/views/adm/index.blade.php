@extends('adm.main')

@section('titulo', 'Baigorria')

@section('cuerpo')

@endsection